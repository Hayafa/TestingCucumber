package com.cg.github.run;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features=("feature"),
		glue= {"com.cg.github.stepdefinition"},
		tags= {"@execute"}
		)
public class TestRunner {
	

}
