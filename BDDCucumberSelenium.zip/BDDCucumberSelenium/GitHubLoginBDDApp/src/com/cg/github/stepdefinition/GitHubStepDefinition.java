package com.cg.github.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.LoginPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubStepDefinition {

	private WebDriver driver;
	private LoginPage loginPage;
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\111_Haya_Fatima\\BDDCucumberSelenium\\chromedriver.exe");
	}
	@Given("^User is on the login page https://github\\.com/login$")
	public void user_is_on_the_login_page_https_github_com_login() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		loginPage=PageFactory.initElements(driver, LoginPage.class);
	}
	@When("^User enters incorrect LoginId or Password\\.$")
	public void user_enters_incorrect_LoginId_or_Password() throws Throwable {
		loginPage.setUsername("hayafa786@gmail.com");
		loginPage.setPassword("Haya@786");
		loginPage.clickSignIn();
	}
	@Then("^'Incorrect username or password\\.'Message should be displayed\\.$")
	public void incorrect_username_or_password_Message_should_be_displayed() throws Throwable {
		String expectedErrorMessage="Incorrect username or password.";
		Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
	}
	@When("^User enters correct LoginId and Password\\.$")
	public void user_enters_correct_LoginId_and_Password() throws Throwable {
		loginPage.setUsername("hayafa786@gmail.com");
		loginPage.setPassword("Hayafa@786");
		loginPage.toString();
	}
	@Then("^User is redirected to page- https://github\\.com/$")
	public void user_is_redirected_to_page_https_github_com() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Hayafa";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
	@After
	public void tearDownStepEnv() {
		driver.close();
	}
}
