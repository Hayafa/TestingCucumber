package com.cg.project.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TempStepDefinition {

	@Given("^: User is on the login page www\\.github\\.com$")
	public void user_is_on_the_login_page_www_github_com() throws Throwable {
	   
	}

	@When("^: User enters LoginId and Password\\.$")
	public void user_enters_LoginId_and_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^: User should be redirected to AccountPage\\.$")
	public void user_should_be_redirected_to_AccountPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	

	}
